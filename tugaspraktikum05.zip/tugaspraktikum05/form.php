<div class="container mt-4">
    <legend>Form Nilai Ujian</legend>
    <hr>
    <form method="POST" action="process.php">
        <!-- Your form fields -->
    </form>
</div>
